<?php
class Lotusbreath_PaymentFilter_Helper_Data extends Mage_Core_Helper_Data
{

    const XML_PATH_PAYMENT_METHODS = 'payment';
    const XML_PATH_PAYMENT_SHIPPING_METHODS = 'carriers';
    const XML_PATH_PAYMENT_GROUPS = 'global/payment/groups';
    const XML_PATH_PAYMENT_FILTER_ENABLE = 'lotusbreath_paymentfilter/general/enabled';

    protected $_disabedPaymentMethodsForCart;
    protected $_shippingOptions = null;

    /*
    public function isModuleEnabled(){
        return Mage::getStoreConfigFlag(self::XML_PATH_PAYMENT_FILTER_ENABLE);
    }
    */

    public function isPaymentFilterEnabled()
    {
        return Mage::getStoreConfigFlag(self::XML_PATH_PAYMENT_FILTER_ENABLE);
    }


    public function getPaymentMethods($store = null)
    {
        if ($store == null) {
            $stores = Mage::app()->getStores();
            $methods = array();
            foreach ($stores as $storeId => $storeItem) {
                //if (in_array(Mage::getStoreConfig(self::XML_PATH_PAYMENT_METHODS, $storeId)))
                    $methods = array_merge($methods, Mage::getStoreConfig(self::XML_PATH_PAYMENT_METHODS, $storeId));
            }

            return $methods;
        } else {
            return Mage::getStoreConfig(self::XML_PATH_PAYMENT_METHODS, $store);
        }

    }

    public function getStorePaymentMethods($store = null, $quote = null)
    {

        $res = array();
        foreach ($this->getPaymentMethods($store) as $code => $methodConfig) {
            $prefix = self::XML_PATH_PAYMENT_METHODS . '/' . $code . '/';

            if (!$model = Mage::getStoreConfig($prefix . 'model', $store)) {
                continue;
            }
            $methodInstance = Mage::getModel($model);
            if (!$methodInstance) {
                continue;
            }
            $methodInstance->setStore($store);
            if (!$methodInstance->isAvailable($quote)) {
                /* if the payment method cannot be used at this time */
                continue;
            }
            $sortOrder = (int)$methodInstance->getConfigData('sort_order', $store);
            $methodInstance->setSortOrder($sortOrder);
            $res[] = $methodInstance;
        }
        return $res;
    }

    public function getForbiddenPaymentMethodsRule($rule = null){

        if ($rule){
            $operator = $rule->getData('condition_operator');
            $ruleId = $rule->getId();
            $productIds = array();

            $items = Mage::getSingleton('checkout/cart')->getQuote()->getAllItems();
            if ($items) {
                foreach ($items as $item) {
                    $productIds[] = $item->getProductId();
                    $product = $item->getProduct();
                    if($product->getTypeId() == "simple"){
                        $parentIds = Mage::getModel('catalog/product_type_grouped')->getParentIdsByChild($product->getId());
                        if(!$parentIds)
                            $parentIds = Mage::getModel('catalog/product_type_configurable')->getParentIdsByChild($product->getId());
                        if ($parentIds)
                            $productIds = array($productIds, $parentIds);
                    }
                    $categoryIds = $item->getProduct()->getCategoryIds();
                }
            }
            //get rule for store
            $storeId = Mage::app()->getStore()->getId();
            $rules = Mage::getModel('lb_paymentfilter/rule')->getCollection();
            $rules->addFieldToFilter('store_id', array('in' => array(0, $storeId)));
            $rules->addFieldToFilter('active', array('eq' => 1));
            $rules->addFieldToFilter('lb_paymentfilter_rule_id', array('eq' => $ruleId));


            $rules->getSelect()->joinLeft(array('rPayment' => $rules->getTable('lb_paymentfilter/rule_payment')), 'rPayment.rule_id = main_table.lb_paymentfilter_rule_id', array('payment_method'));
            if ($rule->getProductIds()){
                $rules->getSelect()->joinLeft(array('rP' => $rules->getTable('lb_paymentfilter/rule_product')), 'rP.rule_id = main_table.lb_paymentfilter_rule_id');
            }

            if($rule->getCategoryIds()){
                $rules->getSelect()->joinLeft(array('rCategory' => $rules->getTable('lb_paymentfilter/rule_category')), 'rCategory.rule_id = main_table.lb_paymentfilter_rule_id');
            }

            if ($rule->getCustomerGroups()){
                $rules->getSelect()->joinLeft(array('rCustomerGroup' => $rules->getTable('lb_paymentfilter/rule_customer_group')), 'rCustomerGroup.rule_id = main_table.lb_paymentfilter_rule_id');
            }


            $filterArrayAttributes = array();

            $filterArrayValues = array();
            if ($rule->getProductIds()){
                if (!empty($productIds)){
                    $filterArrayAttributes[] = 'product_id';
                    $filterArrayValues = array(
                        array('in' => $productIds)
                    );
                }
            }

            if($rule->getCategoryIds()){
                if (!empty($categoryIds)){
                    $filterArrayAttributes[] = 'category_id';
                    $filterArrayValues[] = array('in' => $categoryIds);

                }
            }


            /**
             * Filter by customer and customer group
             */
            $customerSession = Mage::getSingleton('customer/session');
            $customerGroup = 0;
            if ($customerSession->isLoggedIn()) {
                if ($rule->getCustomerIds()){
                    $rules->getSelect()->joinLeft(array('rCustomer' => $rules->getTable('lb_paymentfilter/rule_customer')), 'rCustomer.rule_id = main_table.lb_paymentfilter_rule_id');
                    $customer = $customerSession->getCustomer();
                    $filterArrayAttributes[] = 'customer_id';
                    $filterArrayValues[] = array('eq' => $customer->getId());
                }

                $customerGroup = $customer->getGroupId();
            }
            if ($rule->getCustomerGroups()){
                $filterArrayAttributes[] = 'customer_group_id';
                $filterArrayValues[] = array('eq' => $customerGroup);
            }


            /**
             * shipping method
             */
            if ($rule->getShippingMethods()){
                $checkout = Mage::getSingleton('checkout/session');
                if ($quote = $checkout->getQuote()) {
                    $shippingMethod = $quote->getShippingAddress()->getShippingMethod();
                    if ($shippingMethod) {
                        $rules->getSelect()->joinLeft(array('rSM' => $rules->getTable('lb_paymentfilter/rule_shipping_method')), 'rSM.rule_id = main_table.lb_paymentfilter_rule_id');
                        $filterArrayAttributes[] = 'shipping_method';
                        $filterArrayValues[] = array('eq' => $shippingMethod);
                    }
                }
            }

            if (count($filterArrayAttributes) == 0){
                return false;
            }



            $rules->getSelect()->group('payment_method');
            //echo $rules->getSelect(); exit;
            $sql = $rules->getSelect();
            $resource = Mage::getSingleton('core/resource');
            $readConnection = $resource->getConnection('core_read');
            $results = $readConnection->fetchAll($sql);

            $methods = array();
            foreach ($results as $item) {
                $methods[] = $item['payment_method'];
            }

            $methods = array_unique($methods);
            return $methods;
        }
        return false;

    }

    public function getForbiddenPaymentMethodsForCart()
    {

        if (null === $this->_disabedPaymentMethodsForCart) {
            $this->_disabedPaymentMethodsForCart = array();
            $storeId = Mage::app()->getStore()->getId();
            $rules = Mage::getModel('lb_paymentfilter/rule')->getCollection();
            $rules->addFieldToFilter('store_id', array('in' => array(0, $storeId)));
            $rules->addFieldToFilter('active', array('eq' => 1));
            foreach ($rules as $rule){
                $fullRule = Mage::getModel('lb_paymentfilter/rule')->load($rule->getId());
                $methods = $this->getForbiddenPaymentMethodsRule($fullRule);
                if ($methods){
                    $this->_disabedPaymentMethodsForCart = array_merge($this->_disabedPaymentMethodsForCart, $methods);
                }
            }
            $this->_disabedPaymentMethodsForCart = array_unique($this->_disabedPaymentMethodsForCart);
        }

        return $this->_disabedPaymentMethodsForCart;
    }

    public function getAllShippingOptions(){

        if ($this->_shippingOptions == null){
            $shippingMethods = Mage::getSingleton('shipping/config')->getAllCarriers();
            uasort ($shippingMethods, array($this, 'sortShippingMethods'));

            foreach($shippingMethods as $code => $shippingMethod){
                if(!$title = Mage::getStoreConfig("carriers/$code/title"))
                    $title = $code;
                if ($childMethods = $shippingMethod->getAllowedMethods()){
                    $value = array();
                    foreach ($childMethods as $childCode => $childMethod){
                        /*$value[] = array(
                            'value' => $code .'_'.$childCode,
                            'label' => $childMethod
                        );*/
                        $shippingMethodOptions[] = array(
                            'value' => $code .'_'.$childCode,
                            'label' => "[ <strong> {$title} </strong>] - ".$childMethod
                        );
                    }
                }else{
                    $value = $code;

                    $shippingMethodOptions[] = array(
                        'value' => $value,
                        'label' => $title
                    );
                }
            }
            $this->_shippingOptions = $shippingMethodOptions;
        }

        return $this->_shippingOptions;
    }

    public function sortShippingMethods($a , $b){
        $aCode = $a->getId();
        $bCode = $b->getId();
        $aAtice  = (int)Mage::getStoreConfig("carriers/{$aCode}/active");
        $bAtice  = (int)Mage::getStoreConfig("carriers/{$bCode}/active");
        return $aAtice <= $bAtice;
        //exit;
    }
}