<?php
$installer = $this;
$installer->installEntities();
$installer->startSetup();

$installer->run("

CREATE TABLE IF NOT EXISTS {$this->getTable('lb_paymentfilter_rule_disabled_shipping_method')}(
    `lb_paymentfilter_rule_disabled_shipping_method_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `rule_id` int(11) NOT NULL,
    `disabled_shipping_method` VARCHAR(128) NOT NULL,
    PRIMARY KEY (`lb_paymentfilter_rule_disabled_shipping_method_id`)
    )ENGINE=InnoDB DEFAULT CHARSET=utf8;

");

$installer->endSetup();