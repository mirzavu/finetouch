<?php
$installer = $this;
$installer->installEntities();
$installer->startSetup();

$installer->run("

ALTER TABLE {$this->getTable('lb_paymentfilter_rule')} ADD COLUMN `condition_operator` INT(1) NULL;

");

$installer->endSetup();