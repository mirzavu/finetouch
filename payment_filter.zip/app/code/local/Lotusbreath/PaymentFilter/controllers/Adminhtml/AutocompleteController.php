<?php
class Lotusbreath_PaymentFilter_Adminhtml_AutocompleteController extends Mage_Adminhtml_Controller_Action {


    public function productsAction(){

        $queryString = $this->getRequest()->getParam('q');

        $products = Mage::getModel('catalog/product')->getCollection()
            ->addAttributeToSelect('sku')
            ->addAttributeToSelect('name')
            ->addAttributeToSelect('attribute_set_id')
            ->addAttributeToSelect('type_id');

        ;
        $queryString = "%{$queryString}%";
        $products->addAttributeToFilter(
            array(
                array('attribute' => 'sku',  'like' => $queryString),
                array('attribute' => 'name',  'like' => $queryString)
            )
        )
        ;



        $returnData = array();
        foreach ($products as $product){
            $returnData[] = array(
                'value' => $product->getSKU(),
                'label' => $product->getSKU() . '-' .$product->getName(),
                'id' => $product->getId()
            );
            //$returnData[] = $product->getName();
        }
        $jsonData =  Mage::helper('core')->jsonEncode($returnData);
        $this->getResponse()->setHeader('Content-type', 'application/json');
        $this->getResponse()->setBody($jsonData);

    }
}

