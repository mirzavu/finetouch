<?php
class Lotusbreath_PaymentFilter_Block_Adminhtml_Rule_Edit_Tabs_Product extends Mage_Adminhtml_Block_Widget_Grid{

    public function __construct()
    {
        parent::__construct();
        $this->setId('rule_product_grid');
        $this->setDefaultSort('entity_id');
        $this->setDefaultDir('ASC');
        $this->setSkipGenerateContent(true);
        $this->setSaveParametersInSession(true);
        $this->setUseAjax(true);
    }

    protected function _prepareCollection(){
        $collection = Mage::getModel('catalog/product')->getCollection();
        $collection->addAttributeToSelect('name');
        $this->setCollection($collection);
        parent::_prepareCollection();
        return $this;
    }

    protected  function _prepareColumns(){

        $this->addColumn('selected_product_ids', array(
            'header_css_class'  => 'a-center',
            'type'              => 'checkbox',
            'name'              => 'product_ids',
            'values'            => $this->getSelectedProducts(),
            'align'             => 'center',
            'index'             => 'entity_id',
            'validate_class' => 'validate-one-required',
            'field_name' => 'selected_product_ids[]',
        ));

        $this->addColumn('entity_id',
            array(
                'header'=> Mage::helper('lb_paymentfilter')->__('ID'),
                'width' => '50px',
                'type'  => 'number',
                'index' => 'entity_id',
            ));
        $this->addColumn('sku',
            array(
                'header'=> Mage::helper('lb_paymentfilter')->__('SKU'),
                'index' => 'sku',
            ));
        $this->addColumn('name',
            array(
                'header'=> Mage::helper('lb_paymentfilter')->__('Name'),
                'index' => 'name',
            ));

        $categoriesArray = Mage::getModel('catalog/category')
            ->getCollection()
            ->addAttributeToSelect('name')
            ->addAttributeToSelect('url_path')
            ->addAttributeToSort('path', 'asc')
            ->addFieldToFilter('is_active', array('eq'=>'1'))
            ->addFieldToFilter('level', array('gt'=>1))
            ->load()
            ->toArray();

        $categories = array();
        foreach ($categoriesArray as $categoryId => $category) {
            if (isset($category['name'])) {
                $categories[$category['entity_id']] = Mage::helper('lb_paymentfilter')->__($category['name']);

            }
        }
        $this->addColumn('categories',
            array(
                'header'=> Mage::helper('lb_paymentfilter')->__('Categories'),
                'index' => 'category_ids',
                'renderer' => new Lotusbreath_PaymentFilter_Block_Adminhtml_Rule_Grid_Column_Category(),
                'type' => 'options',
                'options'  => $categories,
                'filter_condition_callback' => array($this, '_filterCateCallback')
            ));

        return parent::_prepareColumns();
    }

    protected function _filterCateCallback($collection, $column){
        $value = $column->getFilter()->getValue();
        $_category = Mage::getModel('catalog/category')->load($value);
        $collection->addCategoryFilter($_category);
        return $collection;
    }


    public function getGridUrl()
    {
        return $this->_getData('grid_url') ? $this->_getData('grid_url') : $this->getUrl('*/*/productgrid', array('_current'=>true));
    }

    public function getSelectedProducts(){
        if ($this->getData('product_ids')){
            return $this->getData('product_ids');
        }else{
            $paymentRule = Mage::registry('lb_paymentrule');
            if ($paymentRule){
                return $paymentRule->getProductIds();
            }

        }
    }

    protected function _addColumnFilterToCollection($column)
    {
        if ($column->getId() == 'selected_product_ids') {
            $productIds = $this->getSelectedProducts();
            if (empty($productIds)) {
                $productIds = 0;
            }
            if ($column->getFilter()->getValue()) {
                $this->getCollection()->addFieldToFilter('entity_id', array('in'=>$productIds));
            }
            elseif(!empty($productIds)) {
                $this->getCollection()->addFieldToFilter('entity_id', array('nin'=>$productIds));
            }
        }
        else {
            parent::_addColumnFilterToCollection($column);
        }
        return $this;
    }
}