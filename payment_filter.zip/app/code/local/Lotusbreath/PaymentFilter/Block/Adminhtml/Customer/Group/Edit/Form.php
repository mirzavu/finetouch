<?php
class Lotusbreath_PaymentFilter_Block_Adminhtml_Customer_Group_Edit_Form extends Mage_Adminhtml_Block_Customer_Group_Edit_Form{
    protected function _prepareLayout()
    {

        parent::_prepareLayout();
        $helper = Mage::helper('lb_paymentfilter');
        if ($helper->isModuleEnabled()){
            $form = $this->getForm();
            $fieldset = $form->addFieldset('paymentfilter_fieldset', array('legend'=> Mage::helper('lb_paymentfilter')->__('Payment Filters')));


            $ruleField = $fieldset->addField('payment_filter_rule', 'multiselect', array(
                'name'  => 'payment_filter_rule',
                'label' => Mage::helper('lb_paymentfilter')->__('Apply these filter rules for this group'),
                'title' => Mage::helper('lb_paymentfilter')->__('Apply these filter rules for this group'),
                'class' => '',
                'required' => false,
                'values' => Mage::getModel('lb_paymentfilter/rule')->getSelectFieldOptions(),
                //'value' => $value,

            ));
            if ($currentGroup = Mage::registry('current_group')){
                $productRuleCollection = Mage::getModel('lb_paymentfilter/rule_customer_group')->getCollection()
                    ->addFieldToFilter('customer_group_id', array('eq' => $currentGroup->getId()))
                ;
                $ruleIds = $productRuleCollection->getColumnValues('rule_id');
                $ruleField->setValue($ruleIds);
            }
        }
        return $this;
    }
}