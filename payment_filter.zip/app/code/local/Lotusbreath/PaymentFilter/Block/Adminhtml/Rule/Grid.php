<?php
class Lotusbreath_PaymentFilter_Block_Adminhtml_Rule_Grid extends Mage_Adminhtml_Block_Widget_Grid{

    public function __construct() {
        parent::__construct ();
        $this->setId ( 'paymentfilterRuleGrid' );
        $this->setDefaultSort ( 'lb_paymentfilter_rule_id' );
        $this->setDefaultDir ( 'DESC' );
        $this->setSaveParametersInSession ( true );
    }
    protected function _prepareCollection() {
        $collection = Mage::getModel ( 'lb_paymentfilter/rule' )->getCollection ();

        //$collection->getSelect()->group('id');
        $this->setCollection ( $collection );
        return parent::_prepareCollection ();
    }

    protected function _prepareColumns() {


        $this->addColumn ( 'name', array (
            'header' => $this->__ ( 'Name' ),
            'align' => 'left',

            'type' => 'text',

            'index' => 'name',
        ));
        $this->addColumn ( 'store_id', array (
            'header' => $this->__ ( 'Store View' ),
            'align' => 'left',

            'type' => 'store',
            'index' => 'store_id',
            //'filter_condition_callback' => array($this, '_maintableEqualFilter')
            //'filter_condition_callback' => array($this, '_storeFilter'),
        ) );

        $methods = array();
        $stores = Mage::app()->getStores();
        foreach ($stores as $storeId => $storeItem){
            //$methods = array_merge($methods, );
            $methodsOfStore = Mage::helper('lb_paymentfilter')->getStorePaymentMethods($storeId);
            foreach ($methodsOfStore as $mt){
                if (!array_key_exists($mt->getCode(), $methods)){
                    $methods[$mt->getCode()] = $mt->getTitle();
                }
            }


        }
        $this->setColumnFilters(array(
            'payment_method' => 'lb_paymentfilter/adminhtml_rule_grid_filter_payment'
        ));

        $this->addColumn ( 'payment_method', array (
            'header' => $this->__ ( 'Payment Methods Restriction' ),
            'align' => 'right',
            'index' => 'payment_method',
            'type' => 'payment_method',
            'renderer' => new Lotusbreath_PaymentFilter_Block_Adminhtml_Rule_Grid_Renderer_Paymentmethods(),
            'options' => $methods,
            'filter_condition_callback' => array($this, '_paymentFilter'),

        ) );

        $shippingAddon = new Lotusbreath_PaymentFilter_Addon_Shipping_Method();
        $shippingAddon->addShippingGridColumn($this);





        $this->addColumn ( 'active', array (
            'header' => $this->__ ( 'Status' ),
            'align' => 'left',
            'type' => 'options',
            'index' => 'active',
            'options' => array(1 => 'Enabled', 0 => 'Disabed')
        ));



    }

    protected function _prepareMassaction() {
        $this->setMassactionIdField ( 'id' );
        $this->getMassactionBlock ()->setFormFieldName ( 'lb_paymentfilter_rule' );

        $this->getMassactionBlock ()->addItem ( 'delete', array (
            'label' => $this->__ ( 'Delete' ),
            'url' => $this->getUrl ( '*/*/massDelete' ),
            'confirm' => $this->__ ( 'Are you sure?' )
        ) );

        $this->getMassactionBlock ()->addItem ( 'enable', array (
            'label' => $this->__ ( 'Enable' ),
            'url' => $this->getUrl ( '*/*/massEnable' ),
            'confirm' => $this->__ ( 'Are you sure?' )
        ) );

        $this->getMassactionBlock ()->addItem ( 'disable', array (
            'label' => $this->__ ( 'Disable' ),
            'url' => $this->getUrl ( '*/*/massDisable' ),
            'confirm' => $this->__ ( 'Are you sure?' )
        ) );

        return $this;
    }
    public function getRowUrl($row) {
        return $this->getUrl ( '*/*/edit', array (
            'id' => $row->getId ()
        ) );
    }

    protected function _paymentFilter($collection, $column){
        if (!$value = $column->getFilter()->getValue()) {
            return $this;
        }

        $collection->join(
            array('payment' => 'lb_paymentfilter/rule_payment'),
            'main_table.lb_paymentfilter_rule_id=payment.rule_id',
            array('payment_method')
            );

        $collection->getSelect()->where(
            "payment_method = ?"
            , "$value");


        return $this;
    }

    protected function _disabledshippingFilter($collection, $column){
        if (!$value = $column->getFilter()->getValue()) {
            return $this;
        }

        $collection->join(
            array('disabled_shipping' => 'lb_paymentfilter/rule_shipping_disabled'),
            'main_table.lb_paymentfilter_rule_id=disabled_shipping.rule_id',
            array('disabled_shipping_method')
        );

        $collection->getSelect()->where(
            "disabled_shipping_method LIKE ?"
            , "%$value%");

        $collection->getSelect()->group('lb_paymentfilter_rule_id');

        return $this;
    }


}