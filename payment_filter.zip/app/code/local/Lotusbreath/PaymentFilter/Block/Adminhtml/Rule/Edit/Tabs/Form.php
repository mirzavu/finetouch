<?php
class Lotusbreath_PaymentFilter_Block_Adminhtml_Rule_Edit_Tabs_Form extends Mage_Adminhtml_Block_Widget_Form{

    public function _prepareForm(){
        $form = new Varien_Data_Form ();
        $this->setForm ( $form );

        $fieldset = $form->addFieldset ( 'general', array (
            'legend' => $this->__ ( 'General' )
        ) );

        $fieldset->addField('id', 'hidden', array(
            'name' => 'id'
        ));
        $fieldset->addField('name', 'text', array(
            'name' => 'rule[name]',
            'required' => true,
            'label' => $this->__('Name'),
            'title' => $this->__('Name'),
        ));
        $fieldset->addField('store_id', 'select', array(
            'name' => 'rule[store_id]',
            'required' => true,
            'class' => 'validate-select validate-select-store',
            'label' => $this->__('Store'),
            'title' => $this->__('Store'),
            'values' => Mage::getSingleton('adminhtml/system_store')
                ->getStoreValuesForForm(false, true),
        ))
        ;

        $fieldset->addField('active', 'select', array(
            'name' => 'rule[active]',
            'label' => $this->__('Status'),
            'title' => $this->__('Status'),
            'values' => array(0 => 'Disabled', 1=> 'Enabled'),
            'value' => 1
        ));

        $stores = Mage::app()->getStores();
        $methods = array();
        foreach ($stores as $storeId => $storeItem){
            //$methods = array_merge($methods, );
            $methodsOfStore = Mage::helper('lb_paymentfilter')->getStorePaymentMethods($storeId);
            foreach ($methodsOfStore as $mt){
                if (!array_key_exists($mt->getCode(), $methods)){
                    $methods[$mt->getCode()] = $mt;
                }
            }
        }

        $methodValues = array();
        foreach ($methods as $method){
            $methodValues[] = array(
                'label' => $method->getTitle(),
                'value' => $method->getCode(),
            );
        }

        $fieldset->addField('payment_method','checkboxes',
            array (
                'label' => $this->__ ( 'The Filter Rule will disable these Payment methods' ),
                'required' => true,
                'name' => 'rule[payment_method][]',
                'values' => $methodValues
            ));

        $shippingAddon = new Lotusbreath_PaymentFilter_Addon_Shipping_Method();
        $shippingAddon->addShippingMethodApplied($fieldset);


        $fieldset->addField('condition_operator', 'select', array(
            'name' => 'rule[condition_operator]',
            'label' => $this->__('Condition Operator'),
            'title' => $this->__('Condition Operator'),
            'values' => array(0 => $this->__('Or'), 1=> $this->__('And')),
            'value' => 1
        ));


        $customerGroups[] = array(
            'value' => '',
            'label' => $this->__('No select')
        );
        $customerGroups[] = array(
            'value' => 0,
            'label' => $this->__('Not Logged in')
        );
        $customerGroups = array_merge($customerGroups, Mage::helper('customer')->getGroups()->toOptionArray());

        $fieldset->addField('customer_group','checkboxes',
            array (
                'label' => $this->__ ( 'Apply to Customer Group' ),
                'name' => 'rule[customer_group][]',
                'values' => $customerGroups
            ));



        $shippingMethodOptions = Mage::helper('lb_paymentfilter')->getAllShippingOptions();


        $fieldset->addField('shipping_method','checkboxes',
            array (
                'label' => $this->__ ( 'Apply to these shipping methods' ),
                'name' => 'rule[shipping_method][]',
                'values' => $shippingMethodOptions,
                'after_element_html' => "<style> .checkboxes{padding: 5px ;max-height: 250px; overflow-y: scroll; border : 1px solid #c0c0c0}</style>"
            ));



        $categoriesArray = Mage::getModel('catalog/category')
            ->getCollection()
            ->addAttributeToSelect('name')
            ->addAttributeToSelect('url_path')
            ->addAttributeToSort('path', 'asc')
            ->addFieldToFilter('is_active', array('eq'=>'1'))
            ->addFieldToFilter('level', array('gt'=>1))
            ->load()
            ->toArray();
        //echo '<pre>'; print_r($categoriesArray);
        //exit;
        $categories = array();
        foreach ($categoriesArray as $categoryId => $category) {
            if (isset($category['name'])) {
                $categories[] = array(
                    'value' => $category['entity_id'],
                    'label' =>  str_repeat('----', $category['level']-2) . Mage::helper('lb_paymentfilter')->__($category['name'])
                );
            }
        }

        $fieldset->addField('categories','checkboxes',
            array (
                'label' => $this->__ ( 'Apply to these categories' ),
                'name' => 'rule[category_id][]',
                'values' => $categories
            ));



        $paymentRule = Mage::registry('lb_paymentrule');
        if($paymentRule){
            $formData = $paymentRule->getData();
            $formData['id'] = $formData['lb_paymentfilter_rule_id'];
            $formData['payment_method'] = $paymentRule->getPaymentMethods();
            $formData['customer_group'] = $paymentRule->getCustomerGroups();
            $formData['shipping_method'] = $paymentRule->getShippingMethods();
            $formData['categories'] = $paymentRule->getCategoryIds();
            $formData = $shippingAddon->addAdditionFormData($formData, $paymentRule);
            $form->setValues($formData);
        }


        $this->setForm($form);
    }


}