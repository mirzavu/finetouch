<?php
class Lotusbreath_PaymentFilter_Block_Adminhtml_Rule_Edit_Tabs_Customer extends Mage_Adminhtml_Block_Widget_Grid{

    public function __construct()
    {
        parent::__construct();
        $this->setId('rule_customer_grid');
        $this->setDefaultSort('entity_id');
        $this->setDefaultDir('ASC');
        $this->setSkipGenerateContent(true);
        $this->setSaveParametersInSession(true);
        $this->setUseAjax(true);
    }

    protected function _prepareCollection(){
        $collection = Mage::getModel('customer/customer')->getCollection();
        $collection->addNameToSelect()
        ;
        $collection->addAttributeToSelect('group');
        //echo '<pre>'; print_r($collection->load()->toArray());exit;
        $this->setCollection($collection);
        return parent::_prepareCollection();
    }

    protected  function _prepareColumns(){

        $this->addColumn('selected_customer_ids', array(
            'header_css_class'  => 'a-center',
            'type'              => 'checkbox',
            'name'              => 'product_ids',
            'values'            => $this->getSelectedCustomers(),
            'align'             => 'center',
            'index'             => 'entity_id',
            'validate_class' => 'validate-one-required',
            'field_name' => 'selected_customer_ids[]',
        ));

        $this->addColumn('entity_id',
            array(
                'header'=> Mage::helper('lb_paymentfilter')->__('ID'),
                'width' => '50px',
                'type'  => 'number',
                'index' => 'entity_id',
            ));




        $this->addColumn('name',
            array(
                'header'=> Mage::helper('lb_paymentfilter')->__('Name'),
                'index' => 'name',
            ));

        $this->addColumn('email',
            array(
                'header'=> Mage::helper('lb_paymentfilter')->__('Email'),
                'index' => 'email',
            ));


        $groups = Mage::getResourceModel('customer/group_collection')
            ->addFieldToFilter('customer_group_id', array('gt'=> 0))
            ->load()
            ->toOptionHash();

        $this->addColumn('group', array(
            'header'    =>  Mage::helper('customer')->__('Group'),
            'width'     =>  '100',
            'index'     =>  'group_id',
            'type'      =>  'options',
            'options'   =>  $groups,
        ));

        if (!Mage::app()->isSingleStoreMode()) {
            $this->addColumn('website_id', array(
                'header'    => Mage::helper('customer')->__('Website'),
                'align'     => 'center',
                'width'     => '80px',
                'type'      => 'options',
                'options'   => Mage::getSingleton('adminhtml/system_store')->getWebsiteOptionHash(true),
                'index'     => 'website_id',
            ));
        }

        return parent::_prepareColumns();
    }

    public function getGridUrl()
    {
        return $this->_getData('grid_url') ? $this->_getData('grid_url') : $this->getUrl('*/*/customergrid', array('_current'=>true));
    }



    public function getSelectedCustomers(){
        if ($this->getData('customer_ids')){
            return $this->getData('customer_ids');
        }else{
            $paymentRule = Mage::registry('lb_paymentrule');

            if ($paymentRule){

                return $paymentRule->getCustomerIds();
            }

        }
    }

    protected function _addColumnFilterToCollection($column)
    {
        if ($column->getId() == 'selected_customer_ids') {
            $customerIds = $this->getSelectedCustomers();
            if (empty($customerIds)) {
                $customerIds = 0;
            }
            if ($column->getFilter()->getValue()) {
                $this->getCollection()->addFieldToFilter('entity_id', array('in'=>$customerIds));
            }
            elseif(!empty($productIds)) {
                $this->getCollection()->addFieldToFilter('entity_id', array('nin'=>$customerIds));
            }
        }
        else {
            parent::_addColumnFilterToCollection($column);
        }
        return $this;
    }
}