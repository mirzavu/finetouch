<?php
class Lotusbreath_PaymentFilter_Block_Adminhtml_Rule_Edit_Tabs extends  Mage_Adminhtml_Block_Widget_Tabs {
    public function __construct() {
        parent::__construct ();
        $this->setId ( 'lb_paymentfilter_rule_form_tabs' );
        $this->setDestElementId ( 'edit_form' );
        $this->setTitle ( $this->__ ( 'Payment Filter Rule' ) );
    }
    protected function _beforeToHtml() {

        $this->addTab ( 'general_section', array (
            'label' => $this->__ ( 'General' ),
            'title' => $this->__ ( 'General' ),
            'content' => $this->getLayout ()
                ->createBlock ( 'lb_paymentfilter/adminhtml_rule_edit_tabs_form' )
                ->toHtml ()
        ) );

        $this->addTab ( 'product_grid_section', array (
            'label' => $this->__ ( 'Apply to Products' ),
            'title' => $this->__ ( 'Apply to Products' ),
            'url'       => $this->getUrl('*/*/productgridtab', array('_current' => true)),
            'class'     => 'ajax',
        ) );

        $this->addTab ( 'customer_grid_section', array (
            'label' => $this->__ ( 'Apply to Customers' ),
            'title' => $this->__ ( 'Apply to Customers' ),
            'url'       => $this->getUrl('*/*/customergridtab', array('_current' => true)),
            'class'     => 'ajax',
        ) );


        return parent::_beforeToHtml();
    }
}