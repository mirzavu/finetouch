<?php
class Lotusbreath_PaymentFilter_Block_Adminhtml_Rule_Edit_Form extends Mage_Adminhtml_Block_Widget_Form{
    public function _prepareForm(){
        $form = new Varien_Data_Form ( array (
            'id' => 'edit_form',
            'action' => $this->getUrl ( '*/*/save', array (
                'id' => $this->getRequest ()->getParam ( 'id' )
            ) ),
            'method' => 'post',
            'enctype' => 'multipart/form-data'
        ) );

        $form->setUseContainer ( true );
        $this->setForm($form);
        return $this;
        $fieldset = $form->addFieldset ( 'general', array (
            'legend' => $this->__ ( 'General' )
        ) );
        $fieldset->addType('lb_product', 'Lotusbreath_PaymentFilter_Block_Form_Element_Autocomplete');

        $fieldset->addField('product_id','lb_product',
            array (
                'label' => $this->__ ( 'Product' ),
                'required' => true,
                'name' => 'product_id'
            ))->setRenderer(new Lotusbreath_PaymentFilter_Block_Form_Element_Renderer_Autocomplete());

        $fieldset->addField('id', 'hidden', array(
        ));
        $fieldset->addField('store_id', 'select', array(
            'name' => 'store_id',
            'required' => true,
            'class' => 'validate-select validate-select-store',
            'label' => $this->__('Store'),
            'title' => $this->__('Store'),
            'values' => Mage::getSingleton('adminhtml/system_store')
                ->getStoreValuesForForm(false, true),
        ))
        ;

        $stores = Mage::app()->getStores();
        $methods = array();
        foreach ($stores as $storeId => $storeItem){
            //$methods = array_merge($methods, );
            $methodsOfStore = Mage::helper('lb_paymentfilter')->getStorePaymentMethods($storeId);
            foreach ($methodsOfStore as $mt){
                if (!array_key_exists($mt->getCode(), $methods)){
                    $methods[$mt->getCode()] = $mt;
                }
            }

        }


        $methodValues = array();
        foreach ($methods as $method){
            $methodValues[] = array(
                'label' => $method->getTitle(),
                'value' => $method->getCode(),
            );
        }

        $fieldset->addField('payment_method','multiselect',
            array (
                'label' => $this->__ ( 'Do not apply Payment methods' ),
                'required' => true,
                'name' => 'payment_method',
                'values' => $methodValues
            ));

        $productPayment = Mage::registry('product_payment');
        if($productPayment){
            $form->setValues($productPayment->getData());
        }
        $this->setForm($form);
    }
}