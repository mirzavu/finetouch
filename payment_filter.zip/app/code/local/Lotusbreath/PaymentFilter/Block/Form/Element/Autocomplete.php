<?php
class Lotusbreath_PaymentFilter_Block_Form_Element_Autocomplete extends Varien_Data_Form_Element_Abstract{
    public function __construct($attributes=array())
    {
        parent::__construct($attributes);
        $this->setType('text');
        $this->setExtType('textfield');
    }

    public function getHtml()
    {
        $this->addClass('input-text');
        return parent::getHtml();
    }

    public function getHtmlAttributes()
    {
        return array('type', 'title', 'class', 'style', 'onclick', 'onchange', 'onkeyup', 'disabled', 'readonly', 'maxlength', 'tabindex');
    }

    public function getElementHtml()
    {
        $block = Mage::getBlockSingleton('core/template');
        $block->setTemplate('lotusbreath/paymentfilter/form/element/autocomplete.phtml');
        $block->setElement($this);
        $html = $block->toHtml();
        return $html;
    }

    public function getObject(){
        $value = $this->getValue();
        if((int)$value){
            $product = Mage::getModel('catalog/product')->load($value);
            return $product;

        }
        return false;
    }
}