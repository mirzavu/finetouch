<?php
class Lotusbreath_PaymentFilter_Model_Mysql4_Rule_Payment extends Mage_Core_Model_Mysql4_Abstract {
    public function _construct(){
        $this->_init('lb_paymentfilter/rule_payment', 'lb_paymentfilter_rule_payment_id');
    }
}