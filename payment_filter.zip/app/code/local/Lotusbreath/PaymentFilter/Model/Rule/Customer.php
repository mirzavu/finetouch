<?php
class Lotusbreath_PaymentFilter_Model_Rule_Customer extends Mage_Core_Model_Abstract {
    public function _construct(){
        $this->_init('lb_paymentfilter/rule_customer');
    }
}