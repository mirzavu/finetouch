<?php
class Lotusbreath_PaymentFilter_Model_Override_Shipping_Rate_Result extends  Mage_Shipping_Model_Rate_Result{

    /**
     * Add a rate to the result
     *
     * @param Mage_Shipping_Model_Rate_Result_Abstract|Mage_Shipping_Model_Rate_Result $result
     * @return Mage_Shipping_Model_Rate_Result
     */
    public function append($result)
    {
        if ( class_exists('Lotusbreath_PaymentFilter_Addon_Shipping_Method') ){
            $shippingAddon = new Lotusbreath_PaymentFilter_Addon_Shipping_Method();
            $isShippingFilterEnabled = $shippingAddon->isEnableShippingFilter();
            if ($isShippingFilterEnabled && $result instanceof Mage_Shipping_Model_Rate_Result) {
                $rates = $result->getAllRates();
                foreach ($rates as $rate) {
                    if ($shippingAddon->checkCarrierAvailability($rate)) {
                        $this->append($rate);
                    }
                }
            }else{
                return parent::append($result);
            }
            return $this;

        }else{
            return parent::append($result);
        }


        return $this;
    }
}
