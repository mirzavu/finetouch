<?php
class Lotusbreath_PaymentFilter_Model_Resource_Eav_Mysql4_Setup extends Mage_Eav_Model_Entity_Setup {
    public function getDefaultEntities() {
        return array(
            'catalog_product' => array(
                'entity_model'      => 'catalog/product',
                'attribute_model'   => 'catalog/resource_eav_attribute',
                'table'             => 'catalog/product',
                'additional_attribute_table' => 'catalog/eav_attribute',
                'entity_attribute_collection' => 'catalog/product_attribute_collection',
                'attributes'        => array
                    (
                        'lb_paymentfilter_rule' => array(
                        'group'           => 'Prices',
                        'type'            => 'varchar',
                        'label'           => 'Payment filter Rules for this product',
                        'input'           => 'multiselect',
                        'source'          => 'lb_paymentfilter/config_source_payment_filter',
                        'backend'         => 'lb_paymentfilter/product_entity_backend_payment_filter',
                        'global'          => Mage_Catalog_Model_Resource_Eav_Attribute::SCOPE_WEBSITE,
                        'required'        => true,
                        'default'         => '',
                        'user_defined'    => 1,
                        'required'        => 0,
                        )
                    )
            ),
            'catalog_category'               => array(
                'entity_model'                   => 'catalog/category',
                'attribute_model'                => 'catalog/resource_eav_attribute',
                'table'                          => 'catalog/category',
                'additional_attribute_table'     => 'catalog/eav_attribute',
                'entity_attribute_collection'    => 'catalog/category_attribute_collection',
                'default_group'                  => 'General Information',
                'attributes'                     => array(
                    'lb_paymentfilter_rule'               => array(
                        'user_defined'    => 1,
                        'required'        => 0,
                        'type'                       => 'varchar',
                        'label'                      => 'Payment Filter Rules',
                        'input'                      => 'multiselect',
                        'sort_order'                 => 20,
                        'global'                     => Mage_Catalog_Model_Resource_Eav_Attribute::SCOPE_STORE,
                        'group'                      => 'General',
                        'source'          => 'lb_paymentfilter/config_source_payment_filter',
                        'backend'         => 'lb_paymentfilter/product_category_entity_backend_payment_filter',
                    )
                )
            ),
            'customer'                       => array(
                'entity_model'                   => 'customer/customer',
                'attribute_model'                => 'customer/attribute',
                'table'                          => 'customer/entity',
                'increment_model'                => 'eav/entity_increment_numeric',
                'additional_attribute_table'     => 'customer/eav_attribute',
                'entity_attribute_collection'    => 'customer/attribute_collection',
                'attributes'                     => array(
                    'lb_paymentfilter_rule'         => array(
                        'user_defined'    => 1,
                        'required'        => 0,
                        'type'                       => 'varchar',
                        'label'                      => 'Payment Filter Rules',
                        'input'                      => 'multiselect',
                        'sort_order'                 => 20,
                        'global'                     => Mage_Catalog_Model_Resource_Eav_Attribute::SCOPE_STORE,
                        'group'                      => 'General',
                        'source'          => 'lb_paymentfilter/config_source_payment_filter',
                        'backend'         => 'lb_paymentfilter/Customer_entity_backend_payment_filter',
                    ),
                )
            )

        );
    }
}