<?php
class Lotusbreath_Paymentfilter_Model_Customer_Entity_Backend_Payment_Filter extends  Mage_Eav_Model_Entity_Attribute_Backend_Array {

    public function beforeSave($object)
    {
        $data = $object->getData($this->getAttribute()->getAttributeCode());
        if (! isset($data)) $data = array();
        elseif (is_string($data)) $data = explode(',', $data);
        elseif (! is_array($data)) $data = array();
        $object->setData($this->getAttribute()->getAttributeCode(), $data);
        return parent::beforeSave($object);
    }

    /**
     * After load method
     *
     * @param Varien_Object $object
     * @return Mage_Eav_Model_Entity_Attribute_Backend_Abstract
     */
    public function afterLoad($object)
    {
        $categoryRuleCollection = Mage::getModel('lb_paymentfilter/rule_customer')->getCollection()
            ->addFieldToFilter('customer_id', array('eq' => $object->getId()))
        ;
        $ruleIds = $categoryRuleCollection->getColumnValues('rule_id');
        $object->setData($this->getAttribute()->getAttributeCode(), $ruleIds);
        return parent::afterLoad($object);
    }


    public function afterSave($object){

        $data = $object->getData($this->getAttribute()->getAttributeCode());

        if (! isset($data)) $data = array();
        elseif (is_string($data)) $data = explode(',', $data);
        elseif (! is_array($data)) $data = array();

        try{
            $customerRules = Mage::getModel('lb_paymentfilter/rule_customer')->getCollection()
                ->addFieldToFilter('customer_id', $object->getId());
            $ruleIds = $customerRules->getColumnValues('rule_id');
            $addRules = array_diff($data, $ruleIds);
            if ($addRules){
                foreach($addRules as $ruleId ){

                    $customerRule = Mage::getModel('lb_paymentfilter/rule_customer');
                    $customerRule->addData(array(
                        'rule_id' => $ruleId,
                        'customer_id' => $object->getId()
                    ));
                    Mage::getResourceSingleton('lb_paymentfilter/rule_customer')->save($customerRule);

                }
            }
            $deleteRules = array_diff($ruleIds, $data);
            if ($deleteRules){
                $customerRuleCollection = Mage::getModel('lb_paymentfilter/rule_customer')->getCollection()
                    ->addFieldToFilter('rule_id', array('in' => $deleteRules))
                    ->addFieldToFilter('customer_id', array('eq' => $object->getId()))
                ;
                $customerRuleCollection->walk('delete');
            }
        } catch (Exception $ex){

        }

    }
}