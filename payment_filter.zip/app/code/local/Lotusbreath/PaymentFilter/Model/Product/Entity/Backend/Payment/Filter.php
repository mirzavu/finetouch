<?php
class Lotusbreath_Paymentfilter_Model_Product_Entity_Backend_Payment_Filter extends  Mage_Eav_Model_Entity_Attribute_Backend_Array {

    public function beforeSave($object)
    {
        $data = $object->getData($this->getAttribute()->getAttributeCode());
        if (! isset($data)) $data = array();
        elseif (is_string($data)) $data = explode(',', $data);
        elseif (! is_array($data)) $data = array();
        $object->setData($this->getAttribute()->getAttributeCode(), $data);
        return parent::beforeSave($object);
    }

    /**
     * After load method
     *
     * @param Varien_Object $object
     * @return Mage_Eav_Model_Entity_Attribute_Backend_Abstract
     */
    public function afterLoad($object)
    {
        $productRuleCollection = Mage::getModel('lb_paymentfilter/rule_product')->getCollection()
            ->addFieldToFilter('product_id', array('eq' => $object->getId()))
        ;
        $ruleIds = $productRuleCollection->getColumnValues('rule_id');
        $object->setData($this->getAttribute()->getAttributeCode(), $ruleIds);
        return parent::afterLoad($object);
    }


    public function afterSave($object){

        $data = $object->getData($this->getAttribute()->getAttributeCode());
        if (! isset($data)) $data = array();
        elseif (is_string($data)) $data = explode(',', $data);
        elseif (! is_array($data)) $data = array();

        try{
            $productRules = Mage::getModel('lb_paymentfilter/rule_product')->getCollection()
                ->addFieldToFilter('product_id', $object->getId());
            $ruleIds = $productRules->getColumnValues('rule_id');
            $addRules = array_diff($data, $ruleIds);
            if ($addRules){
                foreach($addRules as $ruleId ){

                    $productRule = Mage::getModel('lb_paymentfilter/rule_product');
                    $productRule->addData(array(
                        'rule_id' => $ruleId,
                        'product_id' => $object->getId()
                    ));
                    Mage::getResourceSingleton('lb_paymentfilter/rule_product')->save($productRule);

                }
            }
            $deleteRules = array_diff($ruleIds, $data);
            if ($deleteRules){
                $productRuleCollection = Mage::getModel('lb_paymentfilter/rule_product')->getCollection()
                    ->addFieldToFilter('rule_id', array('in' => $deleteRules))
                    ->addFieldToFilter('product_id', array('eq' => $object->getId()))
                ;
                $productRuleCollection->walk('delete');
            }
        } catch (Exception $ex){

        }

    }
}