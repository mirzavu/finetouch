<?php
class Lotusbreath_PaymentFilter_Model_Mysql4_Rule_Category extends Mage_Core_Model_Mysql4_Abstract {
    public function _construct(){
        $this->_init('lb_paymentfilter/rule_category', 'lb_paymentfilter_rule_category_id');
    }
}