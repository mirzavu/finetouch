<?php
class Lotusbreath_PaymentFilter_Model_Mysql4_Rule_Customer_Group_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract {
    public function _construct(){
        $this->_init('lb_paymentfilter/rule_customer_group', 'lb_paymentfilter_rule_customer_group_id');
    }
}