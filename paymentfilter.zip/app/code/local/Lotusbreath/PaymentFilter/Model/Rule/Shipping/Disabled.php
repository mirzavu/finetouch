<?php
class Lotusbreath_PaymentFilter_Model_Rule_Shipping_Disabled extends Mage_Core_Model_Abstract {
    public function _construct(){
        $this->_init('lb_paymentfilter/rule_shipping_disabled');
    }
}