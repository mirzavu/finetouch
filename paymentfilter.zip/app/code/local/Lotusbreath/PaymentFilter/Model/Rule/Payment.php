<?php
class Lotusbreath_PaymentFilter_Model_Rule_Payment extends Mage_Core_Model_Abstract {
    public function _construct(){
        $this->_init('lb_paymentfilter/rule_payment');
    }
}