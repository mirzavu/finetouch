<?php
class Lotusbreath_PaymentFilter_Model_Rule extends Mage_Core_Model_Abstract {

    protected  $_productIds = false;
    protected $_lastProductIds = array();

    protected $_categoryIds = false;
    protected $_lastCategoryIds = array();

    protected  $_customerIds = false;
    protected $_lastCustomerIds = array();

    protected  $_paymentMethods = false;
    protected $_lastPaymentMethods = array();

    protected $_customerGroups = false;
    protected $_lastCustomerGroups = array();


    protected $_shippingMethods = false;
    protected $_lastShippingMethods = array();


    public function _construct(){
        $this->_init('lb_paymentfilter/rule');
    }


    public function setProductIds($productIds){
        $this->_hasDataChanges = true;
        $this->_productIds = $productIds;
    }

    public function getProductIds(){

        return $this->_productIds;

    }

    public function setCategoryIds($categoryIds){
        $this->_hasDataChanges = true;
        $this->_categoryIds = $categoryIds;
    }

    public function getCategoryIds(){

        return $this->_categoryIds;

    }

    public function setCustomerIds($customerIds){
        $this->_hasDataChanges = true;
        $this->_customerIds = $customerIds;
    }

    public function getCustomerIds(){

        return $this->_customerIds;

    }

    public function setPaymentMethods($paymentMethods){
        $this->_hasDataChanges = true;
        $this->_paymentMethods = $paymentMethods;
    }

    public function getPaymentMethods(){
        return $this->_paymentMethods;
    }

    public function setCustomerGroups($customerGroups){
        $this->_hasDataChanges = true;
        $this->_customerGroups = $customerGroups;
    }

    public function getCustomerGroups(){
        return $this->_customerGroups;
    }

    public function setShippingMethods($shippingMethods){
        $this->_hasDataChanges = true;
        $this->_shippingMethods = $shippingMethods;
    }

    public function getShippingMethods(){
        return $this->_shippingMethods;
    }

    protected function _afterLoad(){
        if ($this->getId()){
            $ruleProducts = Mage::getModel('lb_paymentfilter/rule_product')->getCollection()
                ->addFieldToFilter('rule_id', array('eq' => $this->getId()));
            ;

            $productIds = $ruleProducts->getColumnValues('product_id');
            $this->setProductIds($productIds);
            $this->_lastProductIds = $productIds;

            $customers = Mage::getModel('lb_paymentfilter/rule_customer')->getCollection()
                ->addFieldToFilter('rule_id', array('eq' => $this->getId()));
            ;

            $customerIds = $customers->getColumnValues('customer_id');
            $this->setCustomerIds($customerIds);
            $this->_lastCustomerIds = $customerIds;

            $rulePayments = Mage::getModel('lb_paymentfilter/rule_payment')->getCollection()
                ->addFieldToFilter('rule_id', array('eq' => $this->getId()));
            ;
            $paymentMethods = $rulePayments->getColumnValues('payment_method');
            $this->setPaymentMethods($paymentMethods);
            $this->_lastPaymentMethods = $paymentMethods;

            $customerGroupPayments = Mage::getModel('lb_paymentfilter/rule_customer_group')->getCollection()
                ->addFieldToFilter('rule_id', array('eq' => $this->getId()));
            ;
            $customerGroups = $customerGroupPayments->getColumnValues('customer_group_id');
            $this->setCustomerGroups($customerGroups);
            $this->_lastCustomerGroups = $customerGroups;

            $shippingMethods = Mage::getModel('lb_paymentfilter/rule_shipping_method')->getCollection()
                ->addFieldToFilter('rule_id', array('eq' => $this->getId()));
            ;
            $shippingMethods = $shippingMethods->getColumnValues('shipping_method');
            $this->setShippingMethods($shippingMethods);
            $this->_lastShippingMethods = $shippingMethods;

            $categorieRules = Mage::getModel('lb_paymentfilter/rule_category')->getCollection()
                ->addFieldToFilter('rule_id', array('eq' => $this->getId()));
            ;
            $categories = $categorieRules->getColumnValues('category_id');
            $this->setCategoryIds($categories);
            $this->_lastCategoryIds = $categories;




        }


        return parent::_afterLoad();
    }
    public function save()
    {
        /**
         * Direct deleted items to delete method
         */
        if ($this->isDeleted()) {
            return $this->delete();
        }

        if (!$this->_hasModelChanged()) {

            return $this;

        }
        $this->_getResource()->beginTransaction();
        $dataCommited = false;
        try {
            $this->_beforeSave();
            if ($this->_dataSaveAllowed) {
                $this->_getResource()->save($this);
                /* Save product rule*/
                if ($this->_productIds !== false){
                    $addProducts = array_diff($this->_productIds, $this->_lastProductIds);
                    if ($addProducts){
                        foreach($addProducts as $productId ){

                            $productRule = Mage::getModel('lb_paymentfilter/rule_product');
                            $productRule->addData(array(
                                'rule_id' => $this->getId(),
                                'product_id' => $productId
                            ));
                            Mage::getResourceSingleton('lb_paymentfilter/rule_product')->save($productRule);

                        }
                    }
                    $deleteProducts = array_diff($this->_lastProductIds, $this->_productIds);
                    if ($deleteProducts){
                        $productRuleCollection = Mage::getModel('lb_paymentfilter/rule_product')->getCollection()
                            ->addFieldToFilter('rule_id', array('eq' => $this->getId()))
                            ->addFieldToFilter('product_id', array('in' => $deleteProducts))
                        ;
                        $productRuleCollection->walk('delete');
                    }
                }

                /*Save customer */
                if ($this->_customerIds !== false){
                    $addCustomers = array_diff($this->_customerIds, $this->_lastCustomerIds);
                    if ($addCustomers){
                        foreach($addCustomers as $customerId ){

                            $customerRule = Mage::getModel('lb_paymentfilter/rule_customer');
                            $customerRule->addData(array(
                                'rule_id' => $this->getId(),
                                'customer_id' => $customerId
                            ));
                            Mage::getResourceSingleton('lb_paymentfilter/rule_customer')->save($customerRule);

                        }
                    }
                    $deleteCustomers = array_diff($this->_lastCustomerIds, $this->_customerIds);
                    if ($deleteCustomers){
                        $customerRuleCollection = Mage::getModel('lb_paymentfilter/rule_customer')->getCollection()
                            ->addFieldToFilter('rule_id', array('eq' => $this->getId()))
                            ->addFieldToFilter('customer_id', array('in' => $deleteCustomers))
                        ;

                        $customerRuleCollection->walk('delete');
                    }
                }

                /* Save payment methods rule*/

                $addPayments = array_diff($this->_paymentMethods, $this->_lastPaymentMethods);
                if ($addPayments){
                    foreach($addPayments as $paymentMethod ){
                        $paymentRule = Mage::getModel('lb_paymentfilter/rule_payment');
                        $paymentRule->addData(array(
                            'rule_id' => $this->getId(),
                            'payment_method' => $paymentMethod
                        ));
                        Mage::getResourceSingleton('lb_paymentfilter/rule_payment')->save($paymentRule);
                    }
                }
                $deletePayments = array_diff($this->_lastPaymentMethods, $this->_paymentMethods);
                if ($deletePayments){
                    $paymentRuleCollection = Mage::getModel('lb_paymentfilter/rule_payment')->getCollection()
                        ->addFieldToFilter('rule_id', array('eq' => $this->getId()))
                        ->addFieldToFilter('payment_method', array('in' => $deletePayments))
                    ;
                    $paymentRuleCollection->walk('delete');
                }

                /* Save customer group rule*/
                if ($this->_customerGroups !== false){
                    $addCustomerGroups = array_diff($this->_customerGroups, $this->_lastCustomerGroups);
                    if ($addCustomerGroups){
                        foreach($addCustomerGroups as $customerGroup ){
                            $customerGroupRule = Mage::getModel('lb_paymentfilter/rule_customer_group');
                            $customerGroupRule->addData(array(
                                'rule_id' => $this->getId(),
                                'customer_group_id' => $customerGroup
                            ));
                            Mage::getResourceSingleton('lb_paymentfilter/rule_customer_group')->save($customerGroupRule);
                        }
                    }
                    $deleteCustomerGroups = array_diff($this->_lastCustomerGroups, $this->_customerGroups);
                    if ($deleteCustomerGroups){
                        $customerGroupRuleCollection = Mage::getModel('lb_paymentfilter/rule_customer_group')->getCollection()
                            ->addFieldToFilter('rule_id', array('eq' => $this->getId()))
                            ->addFieldToFilter('customer_group_id', array('in' => $deleteCustomerGroups))
                        ;
                        $customerGroupRuleCollection->walk('delete');
                    }
                }

                if ($this->_shippingMethods !== false){
                    /* Save shipping methods rule*/
                    $addShippingMethods = array_diff($this->_shippingMethods, $this->_lastShippingMethods);
                    if ($addShippingMethods){
                        foreach($addShippingMethods as $shippingMethod ){
                            $shippingMethodRule = Mage::getModel('lb_paymentfilter/rule_shipping_method');
                            $shippingMethodRule->addData(array(
                                'rule_id' => $this->getId(),
                                'shipping_method' => $shippingMethod
                            ));
                            Mage::getResourceSingleton('lb_paymentfilter/rule_shipping_method')->save($shippingMethodRule);
                        }
                    }
                    $deleteShippingMethods = array_diff($this->_lastShippingMethods, $this->_shippingMethods);
                    if ($deleteShippingMethods){
                        $shippingMethodRuleCollection = Mage::getModel('lb_paymentfilter/rule_shipping_method')->getCollection()
                            ->addFieldToFilter('rule_id', array('eq' => $this->getId()))
                            ->addFieldToFilter('shipping_method', array('in' => $deleteShippingMethods))
                        ;
                        $shippingMethodRuleCollection->walk('delete');
                    }
                }

                if ($this->_categoryIds !== false){
                    /* Save shipping methods rule*/
                    $addCategories = array_diff($this->_categoryIds, $this->_lastCategoryIds);

                    if ($addCategories){
                        foreach($addCategories as $categoryId ){
                            $categoryRule = Mage::getModel('lb_paymentfilter/rule_category');
                            $categoryRule->addData(array(
                                'rule_id' => $this->getId(),
                                'category_id' => $categoryId
                            ));
                            Mage::getResourceSingleton('lb_paymentfilter/rule_category')->save($categoryRule);
                        }
                    }

                    $deleteCategories = array_diff($this->_lastCategoryIds, $this->_categoryIds);
                    if ($deleteCategories){
                        $categoryRuleCollection = Mage::getModel('lb_paymentfilter/rule_category')->getCollection()
                            ->addFieldToFilter('rule_id', array('eq' => $this->getId()))
                            ->addFieldToFilter('category_id', array('in' => $deleteCategories))
                        ;
                        $categoryRuleCollection->walk('delete');
                    }
                }


                $this->_afterSave();



            }
            $this->_getResource()->addCommitCallback(array($this, 'afterCommitCallback'))
                ->commit();
            $this->_hasDataChanges = false;
            $dataCommited = true;
        } catch (Exception $e) {
            $this->_getResource()->rollBack();
            $this->_hasDataChanges = true;
            throw $e;
        }
        if ($dataCommited) {
            $this->_afterSaveCommit();
        }
        return $this;
    }

    protected function _afterDelete(){
        $productRuleCollection = Mage::getModel('lb_paymentfilter/rule_product')->getCollection()
            ->addFieldToFilter('rule_id', array('eq' => $this->getId()))
        ;
        $productRuleCollection->walk('delete');

        $paymentRuleCollection = Mage::getModel('lb_paymentfilter/rule_payment')->getCollection()
            ->addFieldToFilter('rule_id', array('eq' => $this->getId()))
        ;
        $paymentRuleCollection->walk('delete');

        $customerGroupRuleCollection = Mage::getModel('lb_paymentfilter/rule_customer_group')->getCollection()
            ->addFieldToFilter('rule_id', array('eq' => $this->getId()))
        ;
        $customerGroupRuleCollection->walk('delete');

        return parent::_afterDelete();
    }



    public function getSelectFieldOptions(){
        $options = array();
        $paymentRulesCollection = Mage::getModel('lb_paymentfilter/rule')->getCollection()
            ->addFieldToFilter('active', array('eq' => 1) );
        $options[] = array('value' => '', 'label' => Mage::helper('lb_paymentfilter')->__('None select ') );
        if($paymentRulesCollection->getSize()){
            foreach ($paymentRulesCollection as $paymentRule ){
                $options[] = array(
                    'label' => $paymentRule->getName(),
                    'value' => $paymentRule->getId()
                );;
            }
        }
        return $options;
    }

    public function getSelectFieldValues(){
        $options = array();
        $paymentRulesCollection = Mage::getModel('lb_paymentfilter/rule')->getCollection()
            ->addFieldToFilter('active', array('eq' => 1) );
        //$options[] = array('value' => '', 'label' => Mage::helper('lb_paymentfilter')->__('None select ') );
        if($paymentRulesCollection->getSize()){
            foreach ($paymentRulesCollection as $paymentRule ){
                $options[$paymentRule->getId()] = $paymentRule->getName();
            }
        }
        return $options;
    }
}