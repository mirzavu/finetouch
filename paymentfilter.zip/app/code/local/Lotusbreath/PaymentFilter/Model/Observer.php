<?php
class Lotusbreath_PaymentFilter_Model_Observer  {

    public function paymentMethodIsActive($observer)
    {
        if (! Mage::helper('lb_paymentfilter')->isPaymentFilterEnabled())
            return;

        $checkResult = $observer->getEvent()->getResult();
        $method = $observer->getEvent()->getMethodInstance();

        if ($checkResult->isAvailable)
        {
            $disabledMethods = Mage::helper('lb_paymentfilter')->getForbiddenPaymentMethodsForCart();
            if (in_array($method->getCode(), $disabledMethods ))
            {
                $checkResult->isAvailable = false;
            }
        }
    }

    public function afterSavedCustomerGroup($observer){
        $customerGroup = $observer->getObject();
        if ($customerGroup){
            $customerGroupId = $customerGroup->getId();
            $rules = Mage::app()->getRequest()->getParam('payment_filter_rule');
            if ($rules){
                try{
                    $customerGroupRules = Mage::getModel('lb_paymentfilter/rule_customer_group')->getCollection()
                        ->addFieldToFilter('customer_group_id', $customerGroupId);
                    $ruleIds = $customerGroupRules->getColumnValues('rule_id');
                    $addRules = array_diff($rules, $ruleIds);
                    if ($addRules){
                        foreach($addRules as $ruleId ){
                            $customerGroupRule = Mage::getModel('lb_paymentfilter/rule_customer_group');
                            $customerGroupRule->addData(array(
                                'rule_id' => $ruleId,
                                'customer_group_id' => $customerGroupId
                            ));
                            Mage::getResourceSingleton('lb_paymentfilter/rule_customer_group')->save($customerGroupRule);
                        }
                    }
                    $deleteRules = array_diff($ruleIds, $rules);
                    if ($deleteRules){
                        $customerGroupRules = Mage::getModel('lb_paymentfilter/rule_customer_group')->getCollection()
                            ->addFieldToFilter('rule_id', array('in' => $deleteRules))
                            ->addFieldToFilter('customer_group_id', array('eq' => $customerGroupId))
                        ;
                        $customerGroupRules->walk('delete');
                    }
                }  catch (Exception $ex){

                }
            }
        }

    }
}