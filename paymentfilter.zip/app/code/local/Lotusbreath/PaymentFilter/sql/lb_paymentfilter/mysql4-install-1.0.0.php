<?php
$installer = $this;
$installer->installEntities();
$installer->startSetup();

$installer->run("

CREATE TABLE IF NOT EXISTS {$this->getTable('lb_paymentfilter_rule')}(
    `lb_paymentfilter_rule_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(125) NOT NULL,
    `store_id` INT(4) NOT NULL,
    `active` INT(1) DEFAULT 1,
    PRIMARY KEY (`lb_paymentfilter_rule_id`)
    )ENGINE=InnoDB DEFAULT CHARSET=utf8;



  CREATE TABLE IF NOT EXISTS {$this->getTable('lb_paymentfilter_rule_product')}(
    `lb_paymentfilter_rule_product_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `rule_id` int(11) NOT NULL,
    `product_id` INT(11) UNSIGNED NOT NULL,

    PRIMARY KEY (`lb_paymentfilter_rule_product_id`)
    )ENGINE=InnoDB DEFAULT CHARSET=utf8;



  CREATE TABLE IF NOT EXISTS {$this->getTable('lb_paymentfilter_rule_payment')}(
    `lb_paymentfilter_rule_payment_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `rule_id` int(11) NOT NULL,
    `payment_method` VARCHAR(128) NOT NULL,
    PRIMARY KEY (`lb_paymentfilter_rule_payment_id`)
    )ENGINE=InnoDB DEFAULT CHARSET=utf8;


  CREATE TABLE IF NOT EXISTS {$this->getTable('lb_paymentfilter_rule_category')}(
    `lb_paymentfilter_rule_category_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `rule_id` int(11) NOT NULL,
    `category_id` int(11) NOT NULL,
    PRIMARY KEY (`lb_paymentfilter_rule_category_id`)
    )ENGINE=InnoDB DEFAULT CHARSET=utf8;

  CREATE TABLE IF NOT EXISTS {$this->getTable('lb_paymentfilter_rule_customer')}(
    `lb_paymentfilter_rule_customer_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `rule_id` int(11) NOT NULL,
    `customer_id` int(11) NOT NULL,
    PRIMARY KEY (`lb_paymentfilter_rule_customer_id`)
    )ENGINE=InnoDB DEFAULT CHARSET=utf8;

  CREATE TABLE IF NOT EXISTS {$this->getTable('lb_paymentfilter_rule_customer_group')}(
    `lb_paymentfilter_rule_customer_group_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `rule_id` int(11) NOT NULL,
    `customer_group_id` int(11) NOT NULL,
    PRIMARY KEY (`lb_paymentfilter_rule_customer_group_id`)
    )ENGINE=InnoDB DEFAULT CHARSET=utf8;

  CREATE TABLE IF NOT EXISTS {$this->getTable('lb_paymentfilter_rule_shipping_method')}(
    `lb_paymentfilter_rule_shipping_method_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `rule_id` int(11) NOT NULL,
    `shipping_method` VARCHAR(128) NOT NULL,
    PRIMARY KEY (`lb_paymentfilter_rule_shipping_method_id`)
    )ENGINE=InnoDB DEFAULT CHARSET=utf8;

");

$installer->endSetup();