<?php
class Lotusbreath_PaymentFilter_Addon_Shipping_Method {


    protected $_disabledShippingMethods;



    public function addShippingMethodApplied($fieldSet){

        $helper = Mage::helper('lb_paymentfilter');
        $shippingMethodOptions = $helper->getAllShippingOptions();

        $fieldSet->addField('disabled_shipping_method','checkboxes',
            array (
                'label' => $helper->__ ( 'The Filter Rule will disable these Shipping methods' ),
                'name' => 'rule[disabled_shipping_method][]',
                'values' => $shippingMethodOptions,
                'after_element_html' => "<style> .checkboxes{padding: 5px ;max-height: 250px; overflow-y: scroll; border : 1px solid #c0c0c0}</style>"
            ));
    }

    public function addAdditionFormData($formData, $paymentRule){
        if ($paymentRule && $paymentRule->getId()){
            $disabledShippings = Mage::getModel('lb_paymentfilter/rule_shipping_disabled')->getCollection()
                ->addFieldToFilter('rule_id', array('eq' => $paymentRule->getId()));
            ;
            $methods = $disabledShippings->getColumnValues('disabled_shipping_method');

            $formData['disabled_shipping_method'] = $methods;
        }
        return $formData;
    }

    public function saveDisableShipping($rule , $shippingMethods){

        if ($rule && $rule->getId()){

            $disabledShippings = Mage::getModel('lb_paymentfilter/rule_shipping_disabled')->getCollection()
                ->addFieldToFilter('rule_id', array('eq' => $rule->getId()));
            ;
            $disabledShippings->walk("delete");

            foreach($shippingMethods as $method){
                $disableShippingRule = Mage::getModel('lb_paymentfilter/rule_shipping_disabled');
                $disableShippingRule->addData(array(
                    'rule_id' => $rule->getId(),
                    'disabled_shipping_method' => $method
                ));
                $disableShippingRule->save();
            }
        }

    }

    public function isEnableShippingFilter(){
        return true;
    }

    public function checkCarrierAvailability($rate){
        $disabledMethods = $this->getForbiddenShippingMethodsForCart();
        $method = $rate ? $rate->getcarrier().'_'.$rate->getMethod() : NULLL;

        if ($method){
            if ($disabledMethods && in_array($method, $disabledMethods)){
                return false;
            }
        }

        return true;

    }

    public function getForbiddenShippingMethodsForRule($rule = null){

        if ($rule) {
            $operator = $rule->getData('condition_operator');
            $ruleId = $rule->getId();
            /**
             * Filter by product and category
             */


            $productIds = array();
            $methods = array();
            $items = Mage::getSingleton('checkout/cart')->getQuote()->getAllItems();
            if ($items) {
                foreach ($items as $item) {
                    $productIds[] = $item->getProductId();
                    $product = $item->getProduct();
                    //echo $item->getSku();
                    if($product->getTypeId() == "simple"){
                        $parentIds = Mage::getModel('catalog/product_type_grouped')->getParentIdsByChild($product->getId());
                        if(!$parentIds)
                            $parentIds = Mage::getModel('catalog/product_type_configurable')->getParentIdsByChild($product->getId());
                        if ($parentIds)
                            $productIds = array($productIds, $parentIds);
                    }

                    $categoryIds = $item->getProduct()->getCategoryIds();
                }
            }
            //get rule for store
            $storeId = Mage::app()->getStore()->getId();
            $rules = Mage::getModel('lb_paymentfilter/rule')->getCollection();
            $rules->addFieldToFilter('store_id', array('in' => array(0, $storeId)));
            $rules->addFieldToFilter('active', array('eq' => 1));
            $rules->addFieldToFilter('lb_paymentfilter_rule_id', array('eq' => $ruleId));
            //$rules->getSelect()->joinLeft(array('rPayment' => $rules->getTable('lb_paymentfilter/rule_payment')), 'rPayment.rule_id = main_table.lb_paymentfilter_rule_id', array('payment_method'));


            $rules->getSelect()->joinLeft(array('rDisabledShippingMethod' => $rules->getTable('lb_paymentfilter/rule_shipping_disabled')),
                'rDisabledShippingMethod.rule_id = main_table.lb_paymentfilter_rule_id', array('disabled_shipping_method'));

            if ($rule->getProductIds()){

                $rules->getSelect()->joinLeft(array('rP' => $rules->getTable('lb_paymentfilter/rule_product')), 'rP.rule_id = main_table.lb_paymentfilter_rule_id');
            }



            if($rule->getCategoryIds()){
                $rules->getSelect()->joinLeft(array('rCategory' => $rules->getTable('lb_paymentfilter/rule_category')), 'rCategory.rule_id = main_table.lb_paymentfilter_rule_id');
            }


            if ($rule->getCustomerGroups()){
                $rules->getSelect()->joinLeft(array('rCustomerGroup' => $rules->getTable('lb_paymentfilter/rule_customer_group')), 'rCustomerGroup.rule_id = main_table.lb_paymentfilter_rule_id');
            }

            $filterArrayAttributes = array();

            $filterArrayValues = array();

            if ($rule->getProductIds()){
                if (!empty($productIds)){
                    $filterArrayAttributes[] = 'product_id';
                    $filterArrayValues = array(
                        array('in' => $productIds)
                    );
                }
            }
            if($rule->getCategoryIds()){
                if (!empty($categoryIds)){
                    $filterArrayAttributes[] = 'category_id';
                    $filterArrayValues[] = array('in' => $categoryIds);

                }
            }

            /**
             * Filter by customer and customer group
             */
            $customerSession = Mage::getSingleton('customer/session');
            $customerGroup = 0;
            if ($customerSession->isLoggedIn()) {
                if ($rule->getCustomerIds()){
                    $rules->getSelect()->joinLeft(array('rCustomer' => $rules->getTable('lb_paymentfilter/rule_customer')), 'rCustomer.rule_id = main_table.lb_paymentfilter_rule_id');
                    $customer = $customerSession->getCustomer();
                    $filterArrayAttributes[] = 'customer_id';
                    $filterArrayValues[] = array('eq' => $customer->getId());
                }
                $customerGroup = $customer->getGroupId();
            }

            if ($rule->getCustomerGroups()){

                $filterArrayAttributes[] = 'customer_group_id';
                $filterArrayValues[] = array('eq' => $customerGroup);
            }

            if (count($filterArrayAttributes) == 0){
                return false;
            }


            if ($operator == 0){ //OR Operator
                if (count($filterArrayAttributes)){
                    $rules->addFieldToFilter($filterArrayAttributes, $filterArrayValues);
                }

            }else{ // AND Operator
                $idx = 0;

                foreach ($filterArrayAttributes as $attributeName){

                    $condition = $filterArrayValues[$idx];
                    $rules->addFieldToFilter($attributeName, $condition);
                    $idx++;
                }
            }


            $rules->getSelect()->group('disabled_shipping_method');
            $sql = $rules->getSelect();
            $resource = Mage::getSingleton('core/resource');
            $readConnection = $resource->getConnection('core_read');
            $results = $readConnection->fetchAll($sql);

            $methods = array();
            foreach ($results as $item) {
                if (!empty($item['disabled_shipping_method']))
                    $methods[] = $item['disabled_shipping_method'];
            }
            //echo ($sql);
            $methods = array_unique($methods);
            return $methods;
        }
        return false;
    }

    public function getForbiddenShippingMethodsForCart()
    {
        if (null === $this->_disabledShippingMethods) {
            $this->_disabledShippingMethods = array();
            $storeId = Mage::app()->getStore()->getId();
            $rules = Mage::getModel('lb_paymentfilter/rule')->getCollection();
            $rules->addFieldToFilter('store_id', array('in' => array(0, $storeId)));
            $rules->addFieldToFilter('active', array('eq' => 1));
            foreach ($rules as $rule){
                $fullRule = Mage::getModel('lb_paymentfilter/rule')->load($rule->getId());
                $methods = $this->getForbiddenShippingMethodsForRule($fullRule);
                if ($methods){
                    $this->_disabledShippingMethods = array_merge($this->_disabledShippingMethods, $methods);
                }
            }
            $this->_disabledShippingMethods = array_unique($this->_disabledShippingMethods);

        }

        return $this->_disabledShippingMethods;
    }

    public function addShippingGridColumn($grid){

        $helper = Mage::helper("lb_paymentfilter");
        $methods  = $helper->getAllShippingOptions();
        $grid->addColumn ( 'disabled_shipping_method', array (
            'header' => $helper->__ ( 'Shipping Methods Restriction' ),
            'align' => 'right',
            'index' => 'disabled_shipping_method',
            'type' => 'disabled_shipping_method',
            'renderer' => new Lotusbreath_PaymentFilter_Block_Adminhtml_Rule_Grid_Renderer_Disabledshippingmethods(),
            'options' => $methods,
            'filter_condition_callback' => array($this, '_disabledshippingFilter'),

        ) );
    }
}