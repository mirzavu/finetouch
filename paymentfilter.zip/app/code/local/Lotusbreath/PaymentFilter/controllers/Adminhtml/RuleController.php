<?php
class Lotusbreath_PaymentFilter_Adminhtml_RuleController extends Mage_Adminhtml_Controller_Action
{

    public function indexAction()
    {
        $this->loadLayout();
        $this->renderLayout();
    }

    protected function  getRuleFromParam()
    {
        $id = $this->getRequest()->getParam('id', null);
        if ($id) {
            $paymentRule = Mage::getModel('lb_paymentfilter/rule')->load($id);
            Mage::register('lb_paymentrule', $paymentRule);
        }

    }

    public function editAction()
    {
        $this->getRuleFromParam();
        $this->loadLayout();
        $this->renderLayout();
    }

    public function newAction()
    {
        $this->_forward('edit');
    }

    public function saveAction()
    {
        $helper = Mage::helper('lb_paymentfilter');
        $data = $this->getRequest()->getPost('rule');
        $id = $this->getRequest()->getPost('id', null);
        $productIds = false;
        if (isset($data['product_ids'])){
            $productIds = Mage::helper('adminhtml/js')->decodeGridSerializedInput($data['product_ids']);
        }
        $paymentMethods = !empty($data['payment_method']) ? $data['payment_method'] : array();
        $customerGroups = !empty($data['customer_group']) ? $data['customer_group'] : array();
        $shippingMethods = !empty($data['shipping_method']) ? $data['shipping_method'] : array();
        $categories = !empty($data['category_id']) ? $data['category_id'] : array();
        $customerIds = false;
        if (isset($data['customer_ids'])){
            $customerIds = Mage::helper('adminhtml/js')->decodeGridSerializedInput($data['customer_ids']);
        }
        /**
         * @var Lotusbreath_PaymentFilter_Model_Rule
         */
        $rule = Mage::getModel('lb_paymentfilter/rule');
        if ($id){
            $rule = $rule->load($id);
            if (!$rule){
                Mage::getSingleton('adminhtml/session')->addError('Do not find a rule');
                $this->_redirect('*/*/index');
            }
        }
        $rule->addData($data);
        $rule->setProductIds($productIds);
        $rule->setCustomerIds($customerIds);
        $rule->setPaymentMethods($paymentMethods);
        $rule->setCustomerGroups($customerGroups);
        $rule->setShippingMethods($shippingMethods);
        $rule->setCategoryIds($categories);
        try {
            $rule->save();
            $shippingAddon = new Lotusbreath_PaymentFilter_Addon_Shipping_Method();
            $disableShippingMethods = !empty($data['disabled_shipping_method']) ? $data['disabled_shipping_method'] : array();
            $shippingAddon->saveDisableShipping($rule, $disableShippingMethods);

            Mage::getSingleton('adminhtml/session')->addSuccess($helper->__('Saved %s successfully', $rule->getName()));
            $this->_redirect('*/*/index');
        } catch (Exception $ex) {
            Mage::getSingleton('adminhtml/session')->addError($ex->getMessage());
            $this->_redirect('*/*/edit', array('_current' => true, 'id' => $id));
        }


    }

    public function deleteAction()
    {
        $id = $this->getRequest()->getParam('id');
        if ($id) {
            try {
                $helper = Mage::helper('lb_paymentfilter');
                $productPayment = Mage::getModel('lb_paymentfilter/rule')->load($id);
                $productPayment->delete();
                Mage::getSingleton('adminhtml/session')->addSuccess($helper->__('Delete successfully'));
            } catch (Exception $ex) {
                Mage::getSingleton('adminhtml/session')->addError($ex->getMessage());
            }
        }
        $this->_redirect('*/*/index');
    }

    public function massDeleteAction()
    {

        $ids = $this->getRequest()->getParam('lb_paymentfilter_rule');
        $helper = Mage::helper('lb_paymentfilter');
        try {
            foreach ($ids as $id) {
                if ($id) {
                    $productPayment = Mage::getModel('lb_paymentfilter/rule')->load($id);
                    $productPayment->delete();
                }
            }
            Mage::getSingleton('adminhtml/session')->addSuccess($helper->__('Delete successfully'));
        } catch (Exception $ex) {
            Mage::getSingleton('adminhtml/session')->addError($ex->getMessage());
        }

        $this->_redirect('*/*/index');
    }

    public function massEnableAction(){
        $ids = $this->getRequest()->getParam('lb_paymentfilter_rule');
        $helper = Mage::helper('lb_paymentfilter');
        try {
            foreach ($ids as $id) {
                if ($id) {
                    $productPayment = Mage::getModel('lb_paymentfilter/rule')->load($id);
                    $productPayment->active = 1;
                    $productPayment->save();
                }
            }
            Mage::getSingleton('adminhtml/session')->addSuccess($helper->__('Enable successfully'));
        } catch (Exception $ex) {
            Mage::getSingleton('adminhtml/session')->addError($ex->getMessage());
        }

        $this->_redirect('*/*/index');
    }

    public function massDisableAction(){
        $ids = $this->getRequest()->getParam('lb_paymentfilter_rule');
        $helper = Mage::helper('lb_paymentfilter');
        try {
            foreach ($ids as $id) {
                if ($id) {
                    $productPayment = Mage::getModel('lb_paymentfilter/rule')->load($id);
                    $productPayment->active = 0;
                    $productPayment->save();
                }
            }
            Mage::getSingleton('adminhtml/session')->addSuccess($helper->__('Enable successfully'));
        } catch (Exception $ex) {
            Mage::getSingleton('adminhtml/session')->addError($ex->getMessage());
        }

        $this->_redirect('*/*/index');
    }

    public function productgridtabAction()
    {
        $this->getRuleFromParam();
        $this->loadLayout();
        $this->renderLayout();
    }

    public function customergridtabAction()
    {
        $this->getRuleFromParam();
        $this->loadLayout();
        $this->renderLayout();
    }

    public function productGridAction()
    {
        $this->getRuleFromParam();
        $this->loadLayout();
        $this->getLayout()->getBlock('rule_product_grid')->setData('product_ids', $this->getRequest()->getPost('product_ids'));
        $this->renderLayout();
    }


    public function customerGridAction()
    {
        $this->getRuleFromParam();
        $this->loadLayout();
        $this->getLayout()->getBlock('rule_customer_grid')->setData('customer_ids', $this->getRequest()->getPost('customer_ids'));
        $this->renderLayout();
    }
}