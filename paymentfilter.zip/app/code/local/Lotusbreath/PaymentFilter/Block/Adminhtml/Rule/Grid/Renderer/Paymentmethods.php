<?php
class Lotusbreath_PaymentFilter_Block_Adminhtml_Rule_Grid_Renderer_Paymentmethods extends Mage_Adminhtml_Block_Widget_Grid_Column_Renderer_Abstract {

    public function render(Varien_Object $row){
        $paymentMethods = null;
        $id = $row->getId();
        $rule = Mage::getModel('lb_paymentfilter/rule');
        if ($rule = $rule->load($id)){
            $paymentMethods = $rule->getPaymentMethods();
        }
        $html = '';
        if ($paymentMethods){
            $methods = array();
            $stores = Mage::app()->getStores();
            foreach ($stores as $storeId => $storeItem){
                //$methods = array_merge($methods, );
                $methodsOfStore = Mage::helper('lb_paymentfilter')->getStorePaymentMethods($storeId);
                foreach ($methodsOfStore as $mt){
                    if (!array_key_exists($mt->getCode(), $methods)){
                        $methods[$mt->getCode()] = $mt->getTitle();
                    }
                }
            }
            $paymentMethodStrings = array();
            foreach ($paymentMethods as $mt){
                $paymentMethodStrings[] = $methods[$mt];
            }
            $html = implode('<br>', $paymentMethodStrings);
        }
        return $html;
    }
}