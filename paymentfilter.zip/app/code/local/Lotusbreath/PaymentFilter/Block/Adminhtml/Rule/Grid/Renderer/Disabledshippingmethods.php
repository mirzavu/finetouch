<?php
class Lotusbreath_PaymentFilter_Block_Adminhtml_Rule_Grid_Renderer_Disabledshippingmethods
    extends Mage_Adminhtml_Block_Widget_Grid_Column_Renderer_Select {

    public function render(Varien_Object $row){
        $paymentMethods = null;
        $id = $row->getId();
        $helper = Mage::helper('lb_paymentfilter');
        $shippingMethodOptions = $helper->getAllShippingOptions();

        $rule = Mage::getModel('lb_paymentfilter/rule');

        if ($rule = $rule->load($id)){

            $disabledShippings = Mage::getModel('lb_paymentfilter/rule_shipping_disabled')->getCollection()
                ->addFieldToFilter('rule_id', array('eq' => $rule->getId()));
            ;
            $disabledMethods = $disabledShippings->getColumnValues('disabled_shipping_method');


        }

        $html = '';
        if ($shippingMethodOptions){
            $methods = array();
            //$stores = Mage::app()->getStores();

            foreach ($shippingMethodOptions as $method){
                if (in_array($method['value'], $disabledMethods)){
                    $methods[$method['value']] = $method['label'] . " ( ". $method['value']. " ) ";
                }
            }


            $html = implode('<br>', $methods);
        }
        return $html;
    }
}