<?php
class Lotusbreath_PaymentFilter_Block_Adminhtml_Rule_Edit extends Mage_Adminhtml_Block_Widget_Form_Container {
    public function __construct(){
        parent::__construct();
        $this->_objectId = 'id';
        $this->_blockGroup = 'lb_paymentfilter';
        $this->_controller = 'adminhtml_rule';
        $this->_headerText = Mage::helper ( 'lb_paymentfilter' )->__ ( 'Add Payment Filter Rule' );
        $paymentRule = Mage::registry('lb_paymentrule');
        if ($paymentRule){
            $this->_headerText = Mage::helper ( 'lb_paymentfilter' )->__ ( 'Edit Payment Filter Rule %s', $paymentRule->getName() );
        }
    }
}
