<?php
class Lotusbreath_PaymentFilter_Block_Adminhtml_Rule extends Mage_Adminhtml_Block_Widget_Grid_Container {
    public function __construct(){
        $this->_controller = 'adminhtml_rule';
        $this->_blockGroup = 'lb_paymentfilter';
        $this->_headerText = Mage::helper ( 'lb_paymentfilter' )->__ ( 'Payment Filter Rules' );
        parent::__construct ();
    }
}