<?php
class Lotusbreath_PaymentFilter_Block_Adminhtml_Rule_Grid_Column_Category extends Mage_Adminhtml_Block_Widget_Grid_Column_Renderer_Options {
    public function render(Varien_Object $row)
    {
        $product = Mage::getModel('catalog/product')->load($row->getEntityId());
        $cats = $product->getCategoryIds();
        $row->setData($this->getColumn()->getIndex(), $cats);
        return parent::render($row);
    }
}